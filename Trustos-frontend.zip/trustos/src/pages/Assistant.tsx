import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from 'react';
import { AlertTriangle, ArrowRight, ArrowUpRight, CornerDownLeft, LockKeyhole, MessageCircleMore, RotateCcw, Send, Sparkles } from 'lucide-react';
import { Link, useSearchParams } from 'react-router-dom';
import { Eyebrow, InlineNotice } from '../components/Shared';
import { guideService, looksLikeSecret, type GuideReply } from '../services/guideService';

type Message = { id: string; role: 'guide' | 'user'; text?: string; reply?: GuideReply };
const initialMessage: Message = { id: 'intro', role: 'guide', reply: { heading: 'A little guidance goes a long way.', body: "I can explain the recovery journey, privacy boundaries, and what to verify. I don't examine your accounts or take actions on your behalf.", points: [], action: 'What would you like to understand?' } };
const prompts = [
  { title: 'Free support services', question: 'Which services are free?' },
  { title: 'Success-only fee', question: 'When does the 10% fee apply?' },
  { title: 'The recovery process', question: 'How does the recovery process work?' },
  { title: 'Staying private', question: 'What stays on my device?' },
  { title: 'Verifying a result', question: 'How can I verify a result?' },
  { title: 'Protecting my phrase', question: 'Why should I never share a seed phrase?' },
];
export function AssistantPage() {
  const [params] = useSearchParams();
  const [messages, setMessages] = useState<Message[]>([initialMessage]);
  const [draft, setDraft] = useState(params.get('prompt') === 'verification' ? 'How can I verify a result?' : '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const messageArea = useRef<HTMLDivElement>(null);
  const requestId = useRef(0);
  useEffect(() => { if (messageArea.current) messageArea.current.scrollTop = messageArea.current.scrollHeight; }, [messages, busy]);
  async function send(question: string) {
    const text = question.trim();
    if (!text || busy) return;
    setError('');
    if (looksLikeSecret(text)) { setError('This looks like it might contain a recovery phrase, private key, or BIP39 passphrase, so it was not added to the conversation. Never share secrets here. Detection is not guaranteed.'); setDraft(''); return; }
    setMessages((previous) => [...previous, { id: crypto.randomUUID(), role: 'user', text }]);
    setDraft(''); setBusy(true);
    const request = ++requestId.current;
    try {
      const reply = await guideService.reply(text);
      if (request === requestId.current) setMessages((previous) => [...previous, { id: crypto.randomUUID(), role: 'guide', reply }]);
    } catch {
      if (request === requestId.current) setError('Could not prepare guidance. Please try again.');
    } finally { if (request === requestId.current) setBusy(false); }
  }
  function submit(event: FormEvent) { event.preventDefault(); void send(draft); }
  function onKey(event: KeyboardEvent<HTMLTextAreaElement>) { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); void send(draft); } }
  function clearChat() { requestId.current += 1; setBusy(false); setMessages([initialMessage]); setDraft(''); setError(''); }
  return <div className="assistant-page"><div className="page-intro page-intro--short"><Eyebrow index="03 /">TRUSTOS AI</Eyebrow><div className="page-title-row"><div><h1>Guidance for the next step.</h1><p>Ask about recovery, privacy, and verification. No account secrets, and no action taken on your behalf.</p></div></div></div>
    <div className="assistant-layout"><aside className="assistant-rail"><div className="assistant-rail-top"><span className="assistant-rail-icon"><Sparkles size={22} strokeWidth={1.5} /></span><span>GUIDANCE, NOT GUESSWORK</span></div><h2>Where can we help you get clearer?</h2><p>Select a question or write your own. I share prepared answers to common questions, not an assessment of your wallet.</p><div className="assistant-suggestions"><span>SUGGESTED QUESTIONS</span>{prompts.map((prompt, i) => <button type="button" key={prompt.title} onClick={() => { void send(prompt.question); }} disabled={busy}><span>0{i + 1}</span>{prompt.title}<ArrowUpRight size={16} /></button>)}</div><div className="assistant-rail-bottom"><div><LockKeyhole size={19} /><strong>Keep your secrets yours.</strong></div><p>Never send a recovery phrase, private key, BIP39 passphrase, or password. Messages stay in this page's memory and are cleared when you leave or refresh.</p></div></aside>
    <section className="chat-panel" aria-label="Trustos guide conversation"><div className="chat-header"><div className="chat-header-identity"><div className="chat-avatar"><img src="/brand/linuxboss-mark.webp" alt="" /></div><div><strong>Trustos AI</strong><span><i /> Recovery guidance</span></div></div><button type="button" className="chat-clear" onClick={clearChat} title="Clear conversation"><RotateCcw size={17} /> <span>Clear</span></button></div>
      <div className="chat-messages" ref={messageArea} aria-live="polite" aria-relevant="additions text"><div className="chat-date">THIS CONVERSATION</div>{messages.map((message) => <div key={message.id} className={`chat-message chat-message--${message.role}`}>
        {message.role === 'guide' ? <><div className="chat-message-avatar"><img src="/brand/linuxboss-mark.webp" alt="" /></div><div className="guide-bubble"><span className="bubble-label">TRUSTOS GUIDE</span><h3>{message.reply?.heading}</h3><p>{message.reply?.body}</p>{!!message.reply?.points.length && <ul>{message.reply.points.map((point) => <li key={point}>{point}</li>)}</ul>}{message.reply?.action && <div className="bubble-action"><ArrowRight size={15} />{message.reply.action}</div>}</div></> : <div className="user-bubble">{message.text}</div>}
      </div>)}{busy && <div className="chat-message chat-message--guide"><div className="chat-message-avatar"><img src="/brand/linuxboss-mark.webp" alt="" /></div><div className="guide-bubble chat-thinking" role="status"><span className="mini-spinner" /> Preparing guidance…</div></div>}</div>
      <div className="chat-compose"><div className="chat-safety"><AlertTriangle size={15} aria-hidden="true" /> Don't share a seed phrase, private key, BIP39 passphrase, or password.</div>{error && <InlineNotice type="error">{error}</InlineNotice>}<form onSubmit={submit}><label className="sr-only" htmlFor="guide-input">Ask Trustos AI a question</label><textarea id="guide-input" placeholder="Ask about recovery, privacy, or verification…" maxLength={500} rows={2} value={draft} onChange={(e) => setDraft(e.target.value)} onKeyDown={onKey} /><button className="chat-send" type="submit" disabled={!draft.trim() || busy} aria-label="Send question"><Send size={19} /></button></form><div className="chat-compose-foot"><span><CornerDownLeft size={13} /> Enter to send · Shift+Enter for a new line</span><span>{draft.length} / 500</span></div></div>
    </section></div>
    <div className="assistant-next"><MessageCircleMore size={18} /><span>Need to explore an issue step by step?</span><Link to="/app/recovery">Open the guided recovery walkthrough <ArrowUpRight size={16} /></Link></div>
  </div>;
}
